package edu.ucsb.cs156.example.services;

import edu.ucsb.cs156.example.models.SystemInfo;

public abstract class SystemInfoService {
  public abstract SystemInfo getSystemInfo();
}
