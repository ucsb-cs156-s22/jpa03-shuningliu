const studentFixtures = {
 twoStudents: [
    {
      "id": "abcd1234abcd1234abcd1234",
      "firstName": "Chris",
      "lastName": "Gaucho",
      "perm": 1234567
    },
    {
      "id": "abcd5678abcd5678abcd5678",
      "firstName": "Seth",
      "lastName": "VanBrocklin",
      "perm": 6666666
    }
  ]
}

export {studentFixtures }; 