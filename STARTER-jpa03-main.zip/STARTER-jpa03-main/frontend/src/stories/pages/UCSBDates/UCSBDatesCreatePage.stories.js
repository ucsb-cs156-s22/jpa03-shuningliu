
import React from 'react';

import UCSBDatesCreatePage from "main/pages/UCSBDates/UCSBDatesCreatePage";

export default {
    title: 'pages/UCSBDates/UCSBDatesCreatePage',
    component: UCSBDatesCreatePage
};

const Template = () => <UCSBDatesCreatePage />;

export const Default = Template.bind({});




