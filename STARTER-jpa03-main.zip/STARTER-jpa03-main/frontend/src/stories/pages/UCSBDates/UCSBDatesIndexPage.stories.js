
import React from 'react';

import UCSBDatesIndexPage from "main/pages/UCSBDates/UCSBDatesIndexPage";

export default {
    title: 'pages/UCSBDates/UCSBDatesIndexPage',
    component: UCSBDatesIndexPage
};

const Template = () => <UCSBDatesIndexPage />;

export const Default = Template.bind({});




