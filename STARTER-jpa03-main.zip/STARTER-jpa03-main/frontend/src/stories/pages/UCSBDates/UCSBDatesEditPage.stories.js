
import React from 'react';

import UCSBDatesEditPage from "main/pages/UCSBDates/UCSBDatesEditPage";

export default {
    title: 'pages/UCSBDates/UCSBDatesEditPage',
    component: UCSBDatesEditPage
};

const Template = () => <UCSBDatesEditPage />;

export const Default = Template.bind({});



