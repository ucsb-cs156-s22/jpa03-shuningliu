
import React from 'react';

import Footer from "main/components/Nav/Footer";

export default {
    title: 'layouts/BasicLayout/Footer',
    component: Footer
};


const Template = () => {
    return (
        <Footer />
    )
};

export const Default = Template.bind({});