
import React from 'react';

import AppNavbar from "main/components/Nav/AppNavbar";

export default {
    title: 'layouts/BasicLayout/AppNavbar',
    component: AppNavbar
};

const Template = () => <AppNavbar /> ;
export const Default = Template.bind({});