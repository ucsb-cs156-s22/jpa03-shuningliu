
import React from 'react';

import BasicLayout from "main/layouts/BasicLayout/BasicLayout";

export default {
    title: 'layouts/BasicLayout/BasicLayout',
    component: BasicLayout
};

const Template = () => <BasicLayout />;

export const Default = Template.bind({});