import BasicLayout from "main/layouts/BasicLayout/BasicLayout";

export default function TodosCreatePage() {
  return (
    <BasicLayout>
      <div className="pt-2">
        <h1>Todos</h1>
        <p>
          This is where the create page will go
        </p>
      </div>
    </BasicLayout>
  )
}